<header>
	<?php

	if (!isset($_SESSION['name'])) {
		?>
			<a href="login.php">Login</a>
			<a href="register.php">Register</a>
		<?php
	}elseif ($_SESSION["type"] == "manager") {
		?>
			<a href="panel.php">Control</a>
			<a href="logout.php">Logout</a>
		<?php
	}else {
		?>

		<a href="logout.php">Logout</a>

		<?php
	}

	?>
	
	<a href="index.php#search">Search</a>
</header>