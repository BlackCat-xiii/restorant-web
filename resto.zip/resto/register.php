<?php
session_start();
// error_reporting(0);
if (isset($_SESSION['name'])) {
	header("location: index.php");
	exit();
}

if (isset($_POST["submit"])) {
	include("database.php");

	$name = $_POST["name"];
	$email = $_POST["email"];
	$password = $_POST["password"];
	$type = $_POST["type"];
	//check if the email has been used or not
	$check = $db->prepare("SELECT * FROM users WHERE email = :email");
	$check->execute(array(
		"email" => $email
	));

	if ($check->rowCount() == 0) {
		$req = $db->prepare("INSERT INTO users (name, email, password, type) VALUES (:name, :email, :password, :type)");
		$req->execute(array(
			"name" => $name,
			"email" => $email,
			"password" => $password,
			"type" => $type
		));


		$req->closeCursor();

		header("location: login.php");
	}else {
		$error = "Email has been used";
	}

	$check->closeCursor();

	
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Register</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	</style>
</head>
<body>
	
	<?php

	include("header.php");

	?>

	<section>
		<div class="form">
			<form method="post" action="">
				<label>Name:</label>
				<input type="text" name="name" class="txt" placeholder="Your name">
				<label>Email:</label>
				<input type="email" name="email" class="txt" placeholder="email@example.com">
				<label>Password:</label>
				<input type="password" name="password" class="txt" placeholder="supersecretpasword">
				<label>Type of user:</label>
				<select name="type">
					<option value="manager">Restaurant Manager</option>
					<option value="user" selected>User</option>
				</select>
				<br>
				<input type="submit" name="submit" value="Register" class="button">
			</form>
		</div>
	</section>

	<?php
		if (isset($error)) {
			?>
				<script type="text/javascript">
					alert("<?php echo $error; ?>")
				</script>
			<?php
		}
	?>
</body>
</html>