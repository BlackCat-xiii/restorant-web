<?php
session_start();

if (isset($_SESSION['name'])) {
	header("location: index.php");
	exit();
}

if (isset($_POST["submit"])) {
	include("database.php");

	$email = $_POST["email"];
	$password = $_POST["password"];

	$req = $db->prepare("SELECT * FROM users WHERE email = :email AND password = :password");
	$req->execute(array(
		"email" => $email,
		"password" => $password
	));

	if ($req->rowCount() == 1) {
		$info = $req->fetch();

		$_SESSION["id"] = $info["id"];
		$_SESSION["type"] = $info["type"];
		$_SESSION["name"] = $info["name"];
		$_SESSION["email"] = $info["email"];

		header("location: index.php");
		exit();
	}else {
		$error = "User Not Found";
	}

	$req->closeCursor();
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	</style>
</head>
<body>
	
	<?php

	include("header.php");

	?>

	<section>
		<div class="form">
			<form method="post" action="">
				<?php

				if (isset($error)) {
					echo "<h1 style='color: red; text-shadow: none'>" . $error . "</h1>";
				}

				?>
				<label>Email:</label>
				<input type="email" name="email" class="txt" placeholder="email@example.com">
				<label>Password:</label>
				<input type="password" name="password" class="txt" placeholder="supersecretpassword">
				<br>
				<input type="submit" name="submit" value="Login" class="button">
			</form>
		</div>
	</section>

</body>
</html>