<?php

session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>resto</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<?php

	include("header.php");

	?>

	<section>
		<h1>You can find the best restaurant in your area</h1>
		<h2>Our website provide the best searching system for you to search for the best restaurants, search by food, place, street...etc</h2>
		<button>
			<a href="index.php#search" class="button">Search</a>
		</button>
	</section>

	<article>
		<form id="search" method="get" action="">
			<h1>Search</h1>

			<label>Filter By keywords</label>
			<input type="text" name="word" class="txt" placeholder="Chicken, KFC, salad...etc">
			<label>Filter By city</label>
			<input type="text" name="city" class="txt" placeholder="Riadh, Jeddah...etc">
			<label>Filter By street</label>
			<input type="text" name="street" class="txt" placeholder="King Fahad Road...etc">
			<label>Filter By Stars (<span id="cur_star">0</span>)</label>
			<input type="range" name="stars" min="0" max="5" value="0" id="star">
			<br>
			<input type="submit" name="submit" value="Filter" class="button">
		</form>
	</article>
	<nav>
		<?php

			include("database.php");

			if (isset($_GET['word'])) {
				$req = $db->prepare('SELECT * FROM restaurant WHERE (name LIKE "%":w"%" OR menu LIKE "%":w"%" OR description LIKE "%":w"%") AND city LIKE "%":c"%" AND street LIKE "%":s"%"');
				$req->execute(array(
					"w" => $_GET["word"],
					"c" => $_GET["city"],
					"s" => $_GET["street"]
				));
			}else {
				$req = $db->query("SELECT * FROM restaurant");
			}

			while ($info = $req->fetch()) {
				if (isset($_GET["stars"]) and (int) $_GET["stars"] > 0 and (int) $_GET["stars"] < 6) {
					$stars = (int) $_GET["stars"];

					$check = $db->prepare("SELECT AVG(rate) as mid FROM rates WHERE restaurant_id = :id");
					$check->execute(array(
						"id" => $info["id"]
					));

					$mid = $check->fetch()["mid"];

					if ($mid <> null and $mid < $stars) {
						continue;

						$check->closeCursor();
					}

					$check->closeCursor();
				}
				?>

				<div class="card">
					<div class="card_img">
						<img src="<?php echo $info["photo1"]; ?>">
					</div>
					<div class="card_text">
						<h1><?php echo $info["name"]; ?></h1>
						<?php

							if (isset($mid)) {
								echo '<h2>' . round($mid) . ' Stars</h2>';
							}

						?>
						<p><?php echo $info["description"]; ?></p>
						<a href="restaurants.php?id=<?php echo $info["id"]; ?>" class="button">More</a>
					</div>
				</div>

				<?php
			}

			$req->closeCursor();
			

		?>
		
	</nav>

	<script type="text/javascript">
		
		document.getElementById('star').oninput = function(){
			document.getElementById('cur_star').innerText = document.getElementById('star').value
		}
	</script>
</body>
</html>