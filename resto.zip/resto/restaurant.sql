-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2021 at 11:58 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `rates`
--

CREATE TABLE `rates` (
  `id` int(11) NOT NULL,
  `restaurant_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `rates`
--

INSERT INTO `rates` (`id`, `restaurant_id`, `user_id`, `rate`, `comment`) VALUES
(1, 1, 2, 4, 'I really liked it'),
(2, 1, 2, 1, 'No i hate it!!'),
(3, 3, 2, 3, 'عجبني الاكل'),
(4, 2, 2, 5, 'اكل رائع!!!');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `id` int(11) NOT NULL,
  `owner` int(11) NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `menu` text COLLATE utf8_unicode_ci NOT NULL,
  `city` text COLLATE utf8_unicode_ci NOT NULL,
  `street` text COLLATE utf8_unicode_ci NOT NULL,
  `photo1` text COLLATE utf8_unicode_ci NOT NULL,
  `photo2` text COLLATE utf8_unicode_ci NOT NULL,
  `photo3` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`id`, `owner`, `name`, `description`, `menu`, `city`, `street`, `photo1`, `photo2`, `photo3`) VALUES
(1, 1, 'Sultan\'s Steakhouse', 'The best place to eat the best steak in jeddah.', 'Beef Steak 45$\r\nWagyu Steak 142$\r\nSmoked Brisket 37$', 'Jeddah', '‪Prince Saud Al Faisal‬ U Shape Building', 'photos/1_1.jpg', 'photos/1_2.jpg', 'photos/1_3.jpg'),
(2, 3, '', 'اجود وأطيب انواع الاسماك الطازجة.', 'سلطة جمبري 30$\r\nاسماك مشكلة 25$', 'Jeddah', 'king saud ', 'photos/3_1.jpg', 'photos/3_2.jpg', 'photos/3_3.jpg'),
(3, 4, 'مطعم خيال', 'اجود انواع المأكولات المحلية.', 'كباب 1 متر 13$\r\nكبسة 8$\r\nورق عنب 4$', 'Riyadh', 'Prince Sultan Street', 'photos/4_1.jpg', 'photos/4_2.jpg', 'photos/4_3.jpg'),
(4, 5, '@Black_cat__XIII ', 'Black cat was here :)', '1\r\n2\r\n3\r\n4\r\n5', 'Riadh', 'KSU', 'photos/5_1.jpg', 'photos/5_2.jpg', 'photos/5_3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `type` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `type`) VALUES
(1, 'Sultan', 'sultan@yaho.com', '11', 'manager'),
(2, 'Abdellah', 'abdellah@gmail.com', '11', 'user'),
(3, 'Fisher', 'fisher@hotmail.com', '11', 'manager'),
(4, 'Khayal', 'khayal@gmail.com', '11', 'manager'),
(5, 'Black cat', 'Black_cat@agent13.com', 'XIII', 'manager');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `rates`
--
ALTER TABLE `rates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`) USING HASH;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `rates`
--
ALTER TABLE `rates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `restaurant`
--
ALTER TABLE `restaurant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
