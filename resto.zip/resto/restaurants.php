<?php

session_start();
include("database.php");

$req = $db->prepare("SELECT * FROM restaurant WHERE id = :id");
$req->execute(array(
	'id' => $_GET["id"]
));

while ($info = $req->fetch()) {
	$cur_id = $info["id"];
	$cur_owner = $info["owner"];
	$cur_name = $info["name"];
	$cur_description = $info["description"];
	$cur_menu = $info["menu"];
	$cur_location = $info["city"] . " " . $info["street"];
	$cur_photo1 = $info["photo1"];
	$cur_photo2 = $info["photo2"];
	$cur_photo3 = $info["photo3"];
}

$req->closeCursor();

if (isset($_POST['submit']) and $_POST['comment'] != "") {
	$req = $db->prepare("INSERT INTO rates (restaurant_id, user_id, rate, comment) VALUES (:restaurant_id, :id, :rate, :comment)");
	$req->execute(array(
		"restaurant_id" => $_GET["id"],
		"id" => $_SESSION['id'],
		"rate" => $_POST['stars'],
		"comment" => $_POST["comment"]
	));

	$req->closeCursor();

	header("location: restaurants.php?id=" . $_GET["id"]);
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Welcome to - <?php echo $cur_name; ?> - restaurant</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<style type="text/css">
		<?php

		if ($cur_photo2 != "") {
			?>
				section{
					background-image: url("<?php echo $cur_photo2; ?>");
				}
			<?php
		}

		?>
		
	</style>
</head>
<body>
	<?php

	include("header.php");

	?>

	<section>
		<h1><?php echo $cur_name; ?></h1>
		<h2><?php echo $cur_description; ?></h2>
		<h2><?php echo $cur_location; ?></h2>
	</section>

	<article>
		<h1>Menu</h1>
		<ul>
			<?php

			foreach (array_filter(explode("\n", $cur_menu)) as $line) {
				echo "<li>" . $line . "</li>";
			}

			?>
		</ul>
	</article>

	<nav>
		<?php

			foreach (array_filter(array($cur_photo1, $cur_photo3)) as $photo) {
				?>
					<div class="photos">
						<img src="<?php echo $photo; ?>">
					</div>
				<?php
			}

		?>
	</nav>

	<nav>
		<?php
			if (isset($_SESSION['id'])) {
				?>
					<form class="form" method="post">
						<textarea class="txt" placeholder="Write a comment" name="comment"></textarea>
						<input type="range" name="stars" min="1" max="5" value="0" id="star">
						<label>(<span id="cur_star">1</span>) Star</label>
						<input type="submit" name="submit" value="Comment" class="button">
					</form>
				<?php
			}
		?>
		<br>
		<br>
		<br>
		<br>
		<?php

		$req = $db->prepare("SELECT users.name, rates.rate, rates.comment FROM rates LEFT JOIN users ON rates.user_id = users.id WHERE rates.restaurant_id = :id ORDER BY rates.id DESC");
		$req->execute(array(
			"id" => $_GET["id"]
		));

		while ($info = $req->fetch()) {
			?>
				<div class="comment">
					<h1><?php echo $info["name"] ?></h1>
					<h2>Review: <?php echo $info["rate"] ?> stars</h2>
					<p><?php echo $info["comment"] ?></p>
				</div>
			<?php
		}

		$req->closeCursor();

		?>
	</nav>
	<script type="text/javascript">
		
		document.getElementById('star').oninput = function(){
			document.getElementById('cur_star').innerText = document.getElementById('star').value
		}
	</script>
</body>
</html>