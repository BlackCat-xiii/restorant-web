<?php

$host = 'localhost';
$db = 'restaurant';
$login = 'root';
$pass = '';
try {
	$db = new PDO('mysql:host=' . $host . ';dbname=' . $db . '', $login, $pass, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
} catch (Exception $e) {
}

?>