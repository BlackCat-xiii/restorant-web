<?php
session_start();

if (!isset($_SESSION['name']) or $_SESSION['type'] !== "manager") {
	header("location: index.php");
	exit();
}
include("database.php");

$check = $db->prepare("SELECT * FROM restaurant WHERE owner = :id");
$check->execute(array(
	"id" => $_SESSION['id']
));
$number = $check->rowCount();

if ($number == 1) {
	$info = $check->fetch();

	$cur_id = $info["id"];
	$cur_name = $info["name"];
	$cur_description = $info["description"];
	$cur_menu = $info["menu"];
	$cur_city = $info["city"];
	$cur_street = $info["street"];
	$cur_photo1 = $info["photo1"];
	$cur_photo2 = $info["photo2"];
	$cur_photo3 = $info["photo3"];
}else {
	$cur_id = "";
	$cur_name = "";
	$cur_description = "";
	$cur_menu = "";
	$cur_city = "";
	$cur_street = "";
	$cur_photo1 = "";
	$cur_photo2 = "";
	$cur_photo3 = "";
}

$check->closeCursor();

if (isset($_POST["submit"])) {
	

	$name = $_POST["name"];
	$description = $_POST["description"];
	$menu = $_POST["menu"];
	$city = $_POST["city"];
	$street = $_POST["street"];
	$photo1 = $_FILES["photo1"];
	$photo2 = $_FILES["photo2"];
	$photo3 = $_FILES["photo3"];

	if ($photo1["name"] != "") {
		move_uploaded_file($photo1["tmp_name"], 'photos/' . $_SESSION['id'] . "_1.jpg");
		$photo1 = 'photos/' . $_SESSION['id'] . "_1.jpg";
	}else {
		$photo1 = $cur_photo1;
	}
	if ($photo2["name"] != "") {
		move_uploaded_file($photo2["tmp_name"], 'photos/' . $_SESSION['id'] . "_2.jpg");
		$photo2 = 'photos/' . $_SESSION['id'] . "_2.jpg";
	}else {
		$photo2 = $cur_photo2;
	}
	if ($photo3["name"] != "") {
		move_uploaded_file($photo3["tmp_name"], 'photos/' . $_SESSION['id'] . "_3.jpg");
		$photo3 = 'photos/' . $_SESSION['id'] . "_3.jpg";
	}else {
		$photo3 = $cur_photo3;
	}

	if ($number == 1) {
		$req = $db->prepare("UPDATE restaurant SET name = :name, description = :description, menu= :menu, city=:city, street=:street, photo1=:photo1, photo2=:photo2, photo3=:photo3 WHERE owner = :id");
	}else {
		$req = $db->prepare("INSERT INTO restaurant (owner, name, description, menu, city, street, photo1, photo2, photo3) VALUES (:id, :name, :description, :menu, :city, :street, :photo1, :photo2, :photo3)");
	}

	$req->execute(array(
		"id" => $_SESSION["id"],
		"name" => $name,
		"description" => $description,
		"menu" => $menu,
		"city" => $city,
		"street" => $street,
		"photo1" => $photo1,
		"photo2" => $photo2,
		"photo3" => $photo3
	));

	$req->closeCursor();

	header("location: panel.php");

}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Control panel</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	</style>
</head>
<body>
	
	<?php

	include("header.php");

	?>

	<section>
		<div class="form">
			<form method="post" action="" enctype="multipart/form-data">

				<label>Restaurant Name:</label>
				<input type="text" name="name" class="txt" value="<?php echo $cur_name; ?>">
				<label>Restaurant Description:</label>
				<textarea name="description" class="txt" style="height: 5em;"><?php echo $cur_description; ?></textarea>
				<label>Restaurant Menu:</label>
				<textarea name="menu" class="txt" style="height: 5em;"><?php echo $cur_menu; ?></textarea>
				<label>Restaurant City:</label>
				<input type="text" name="city" value="<?php echo $cur_city; ?>" class="txt">
				<label>Restaurant Street:</label>
				<input type="text" name="street" value="<?php echo $cur_street; ?>" class="txt">
				<br>
				<label>Small will be the best</label>
				<input type="file" name="photo1">
				<label>Wide will be the best</label>
				<input type="file" name="photo2">
				<label>Choose Any photo</label>
				<input type="file" name="photo3">
				<br>
				<input type="submit" name="submit" value="Save" class="button">
				<?php
					if ($cur_name != "") {
						echo '<a href="restaurants.php?id=' . $cur_id . '">View</a>';
					}

				?>
			</form>
		</div>
	</section>
</body>
</html>